package day17;

public class Review_abstract1  {

	public static void main(String[] args) {
		
		
//		Animal a = new Animal("돼지", 31) 추상클래스꺼는 못씀
		
	}

}
