package day18;

public class Human {

	String name;
	int age;
	
	public Human(String name, int age) {
		this.name = name;
		this.age = age;
		// TODO Auto-generated constructor stub
	}

	public boolean setPhone(String phone) {
		// TODO Auto-generated method 
		phone.equals(phone);
		return false;
	}


}
