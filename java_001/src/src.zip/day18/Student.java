package day18;

import java.util.ArrayList;

public class Student extends Human{
	
	
	String name;
	int age;
	String stuNo;
	
	public Student(String name, int age, String stuNo) {
		// TODO Auto-generated constructor stub
		super(name, age);
		this.stuNo = stuNo;
	}

	public ArrayList<String> subjectList() {
		// TODO Auto-generated method stub
			
		return subjectList();
	}

}
